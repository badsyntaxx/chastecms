<?php

$data['name'] = 'Frodo Baggins';
$data['have_leaf'] = true;
$data['gender'] = 'Male';

echo json_encode($data);