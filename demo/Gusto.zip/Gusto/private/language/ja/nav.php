<?php 

$_['nav_text_dashboard'] = '概要';
$_['nav_text_users'] = 'ユーザー';
$_['nav_text_pages'] = 'ページ';
$_['nav_text_sitemap'] = 'サイトマップ';
$_['nav_text_blog'] = 'ブログ';
$_['nav_text_modules'] = 'モジュール';
$_['nav_text_analytics'] = 'アナリティクス';
$_['nav_text_popups'] = 'ポップアップ';
$_['nav_text_newsletter'] = 'ニュースレター';
$_['nav_text_settings'] = '設定';
$_['nav_text_logout'] = 'ログアウト';