<?php 

/**
 * Title
 */
$_['title'] = 'Settings';

/**
 * Alerts
 */
$_['setting_updated'] = 'Settings has been updated.';
$_['logs_cleared'] = 'Logs cleared.';
$_['errors_cleared'] = 'Errors cleared.';