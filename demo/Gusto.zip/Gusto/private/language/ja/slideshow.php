<?php 

/**
 * Title
 */
$_['title'] = 'Slideshow';

/**
 * Description
 */
$_['description'] = 'This is the slideshow page description and it is about 160 characters long, which is super important for seo or (search engine optimization). Try to keep it so.';

/**
 * Alerts
 */