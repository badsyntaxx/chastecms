<?php 

/**
 * Title
 */
$_['title'] = 'Terms & Conditions';

/**
 * Description
 */
$_['description'] = 'This is the terms and conditions page description and it is about 160 characters long, which is super important for seo or (search engine optimization). Try to keep it so.';

/**
 * Alerts
 */