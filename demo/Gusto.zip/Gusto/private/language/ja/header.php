<?php 

/**
 * Header
 */
$_['theme_text'] = 'テーマ';
$_['view_text'] = 'プレビュー';
$_['account_text'] = 'アカウント';