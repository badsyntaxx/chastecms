<?php 

/**
 * Title
 */
$_['title'] = 'アナリティクス';

/**
 * Alerts
 */
$_['code_updated'] = '分析コードが保存されました。';
$_['code_not_updated'] = '分析コードが保存されていません。';