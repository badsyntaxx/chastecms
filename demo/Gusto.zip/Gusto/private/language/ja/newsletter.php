<?php 

/**
 * Title
 */
$_['title'] = 'Newsletter';

/**
 * Alerts
 */
$_['newsletter_success'] = 'The newsletter has been sent to the subscribers.';
$_['newsletter_fail'] = 'The message could not be sent.';