<?php 

$_['maintenance_mode'] = 'We are currently undergoing maintenance. Please check back in 30 minutes.';