<?php 

/**
 * Title
 */
$_['title'] = 'Users';

/**
 * Alerts
 */
$_['no_user'] = 'Select a user';
$_['user_updated'] = 'The user records were updated.';
$_['user_not_updated'] = 'The user records were not updated.';
$_['self_edit'] = 'Unable to change user group. Reason: Changing your own group status can result in you being locked out.';
$_['users_deleted'] = 'The users have been deleted from the database.';

/**
 * Logs
 */
$_['log_user_update'] = 'Admin \'{{admin}}\' set user \'{{name}}\' to \'{{group}}\'.';
$_['log_user_update_fail'] = 'Admin \'{{admin}}\' was unable to update user \'{{name}}\'. Check error logs.';