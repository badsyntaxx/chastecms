<?php 

$_['dashboard'] = 'DASHBOARD';
$_['users'] = 'USERS';
$_['calendar'] = 'CALENDAR';
$_['filebrowser'] = 'FILEBROWSER';
$_['pagination'] = 'PAGINATION';
$_['settings'] = 'SETTINGS';
$_['logout'] = 'LOGOUT';