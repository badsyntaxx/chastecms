<?php 

/**
 * Header
 */
$_['theme_text'] = 'Theme';
$_['view_text'] = 'Preview';
$_['account_text'] = 'Account';