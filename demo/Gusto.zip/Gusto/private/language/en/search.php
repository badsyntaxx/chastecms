<?php 

/**
 * Title
 */
$_['title'] = 'Search:';

/**
 * Description
 */
$_['description'] = 'This is the search page description and it is about 160 characters long, which is super important for seo or (search engine optimization). Try to keep it so.';

/**
 * Alerts
 */