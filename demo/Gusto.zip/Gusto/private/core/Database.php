<?php

/**
 * Database Core Class
 *
 * The Database class creates a new mysqli object that can be used for 
 * database connections.
 */
final class Database
{
    /**
     * Database connection.
     * @var object
     */
    public $mysqli;

    /**
     * Store the single instance of Database.
     * @var object
     */
    private static $instance;

    /**
     * Database Class Construct
     * 
     * Private constructor to limit object instantiation to within the class.
     * 
     * @return void
     */
    private function __construct()
    {
        if (!$this->mysqli) {
            $this->mysqli = new mysqli(HOSTNAME, USERNAME, PASSWORD, DATABASE, PORT);
            if ($this->mysqli->connect_error) {
                exit('Failed to connect to the database <br>Error: ' . $this->mysqli->connect_error);
            } 
        }
    }

    /**
     * Get Database Instance
     * 
     * Creating and return a single instance of this class.
     * 
     * @return object
     */
    public static function instance()
    {
        if (!isset(static::$instance)) {
            static::$instance = new static();
        }
        return static::$instance;
    }
}
