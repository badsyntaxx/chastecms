<?php

// Database
define('HOSTNAME', '72.130.42.133');
define('DATABASE', 'techutks_gusto');
define('USERNAME', 'techutks_chase');
define('PASSWORD', 'Th1sP@ssw0rdF0rDB');
define('PORT', 3307);